from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import json

try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    vader_available = True
    sentiment_analyzer = SentimentIntensityAnalyzer()
except ImportError:
    vader_available = False
    sentiment_analyzer = None

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mindease-secret-key-2024-secure'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mental_health.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'warning'


# ==============================================================================
# DATABASE MODELS
# ==============================================================================

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    age = db.Column(db.Integer)
    course = db.Column(db.String(100))
    academic_year = db.Column(db.String(20))
    institution = db.Column(db.String(150))
    bio = db.Column(db.Text)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    mood_entries = db.relationship('MoodEntry', backref='user', lazy=True, cascade='all, delete-orphan')
    surveys = db.relationship('Survey', backref='user', lazy=True, cascade='all, delete-orphan')
    chat_messages = db.relationship('ChatMessage', backref='user', lazy=True, cascade='all, delete-orphan')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class MoodEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    mood_score = db.Column(db.Integer, nullable=False)
    notes = db.Column(db.Text)
    sentiment = db.Column(db.String(20), default='neutral')
    sentiment_score = db.Column(db.Float, default=0.0)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


class Survey(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    workload_level = db.Column(db.Integer)
    stress_level = db.Column(db.Integer)
    sleep_hours = db.Column(db.Float)
    exercise = db.Column(db.Boolean, default=False)
    social_interaction = db.Column(db.Integer)
    feedback = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


class ChatMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text, nullable=False)
    sentiment = db.Column(db.String(20), default='neutral')
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


# ==============================================================================
# SENTIMENT ANALYSIS (Module 3)
# ==============================================================================

def analyze_sentiment(text):
    if not text:
        return 'neutral', 0.0
    if vader_available:
        scores = sentiment_analyzer.polarity_scores(text)
        compound = scores['compound']
        if compound >= 0.05:
            return 'positive', compound
        elif compound <= -0.6:
            return 'highly_negative', compound
        elif compound <= -0.2:
            return 'negative', compound
        else:
            return 'neutral', compound
    else:
        positive_words = ['happy', 'good', 'great', 'excellent', 'wonderful', 'amazing', 'joy', 'excited', 'motivated', 'calm', 'peaceful']
        negative_words = ['sad', 'stressed', 'anxious', 'worried', 'depressed', 'tired', 'exhausted', 'overwhelmed', 'hopeless', 'lonely', 'panic']
        text_lower = text.lower()
        pos_count = sum(1 for w in positive_words if w in text_lower)
        neg_count = sum(1 for w in negative_words if w in text_lower)
        if pos_count > neg_count:
            return 'positive', 0.5
        elif neg_count > pos_count:
            if neg_count >= 3:
                return 'highly_negative', -0.7
            return 'negative', -0.4
        return 'neutral', 0.0


# ==============================================================================
# AI CHATBOT (Module 4)
# ==============================================================================

def generate_chatbot_response(message):
    msg = message.lower().strip()

    # Emergency / crisis keywords
    if any(w in msg for w in ['suicide', 'kill myself', 'end my life', 'want to die', 'self harm']):
        return ("⚠️ I'm very concerned about what you've shared. Please reach out to a mental health "
                "professional immediately.\n\n**Helplines:**\n• iCall: **9152987821**\n"
                "• Vandrevala Foundation: **1860-2662-345** (24/7)\n• Snehi: **044-24640050**\n\n"
                "You are not alone, and help is available. Please talk to someone you trust. 💙")

    if any(w in msg for w in ['stress', 'stressed', 'overwhelmed', 'pressure', 'burden', 'too much']):
        return ("I understand that feeling stressed can be really tough. Here are some tips:\n\n"
                "🧘 **Deep Breathing** – Inhale 4s → Hold 4s → Exhale 6s. Repeat 5 times.\n"
                "📋 **Break Tasks Down** – Divide your workload into small, manageable chunks.\n"
                "🚶 **Take Breaks** – Step away every 45 minutes to refresh your mind.\n"
                "💤 **Rest Well** – 7–8 hours of sleep is essential for managing stress.\n"
                "🎵 **Listen to Music** – Calm music can quickly reduce stress levels.\n\n"
                "Would you like more specific advice on managing stress?")

    if any(w in msg for w in ['anxious', 'anxiety', 'panic', 'nervous', 'worried', 'worry', 'fear', 'scared']):
        return ("Anxiety is very common among students and it's okay to feel this way. Try this:\n\n"
                "🌬️ **Box Breathing** – Inhale 4s → Hold 4s → Exhale 4s → Hold 4s\n"
                "🎯 **5-4-3-2-1 Grounding** – Name 5 things you see, 4 you touch, 3 you hear, 2 you smell, 1 you taste.\n"
                "🗣️ **Talk About It** – Share your feelings with a trusted friend or counselor.\n"
                "🏃 **Exercise** – Even a 10-minute walk significantly reduces anxiety.\n\n"
                "Remember: This feeling is temporary. You will get through it! 💪")

    if any(w in msg for w in ['sad', 'depressed', 'depression', 'lonely', 'alone', 'hopeless', 'worthless', 'empty', 'numb']):
        return ("I hear you, and I'm sorry you're feeling this way. Your feelings are valid. 💙\n\n"
                "Things that might help:\n"
                "🌟 **Self-Compassion** – Treat yourself as you would treat a good friend.\n"
                "📖 **Gratitude Journal** – Write 3 things you're grateful for each day.\n"
                "🤝 **Connect** – Reach out to someone you trust — a friend, family, or counselor.\n"
                "🎨 **Creative Outlet** – Art, music, writing — express what you feel.\n\n"
                "Speaking with a school counselor is a sign of strength, not weakness. "
                "Please consider it if these feelings persist. 💙")

    if any(w in msg for w in ['study', 'exam', 'test', 'assignment', 'homework', 'grade', 'fail', 'academic', 'marks', 'result']):
        return ("Academic pressure is one of the most common challenges students face. Here's how to manage it:\n\n"
                "📅 **Plan Your Schedule** – Use a timetable to organize study sessions.\n"
                "🍅 **Pomodoro Technique** – Study 25 min → Break 5 min → Repeat 4 times → Long break.\n"
                "🎯 **Realistic Goals** – Focus on progress, not perfection.\n"
                "👥 **Study Groups** – Learning with peers makes studying more engaging.\n"
                "🏆 **Celebrate Small Wins** – Reward yourself for completing tasks!\n\n"
                "Remember: your worth is NOT defined by your grades. You are more than your marks. 🌟")

    if any(w in msg for w in ['sleep', 'tired', 'exhausted', 'insomnia', 'fatigue', "can't sleep", 'cannot sleep']):
        return ("Good sleep is foundational for mental health and academic success. Tips:\n\n"
                "⏰ **Consistent Schedule** – Sleep and wake at the same time every day.\n"
                "📵 **No Screens** – Avoid phone/laptop 1 hour before bed (blue light disrupts sleep).\n"
                "🌙 **Bedtime Routine** – Read, stretch, or meditate to signal your brain to wind down.\n"
                "☕ **Limit Caffeine** – No coffee/tea after 3 PM.\n"
                "🌡️ **Cool Room** – A slightly cool environment (around 18–20°C) helps trigger sleep.\n\n"
                "Aim for **7–9 hours** of quality sleep every night! 😴")

    if any(w in msg for w in ['happy', 'great', 'wonderful', 'amazing', 'fantastic', 'excited', 'good', 'joyful']):
        return ("That's wonderful to hear! 🎉 Keep nurturing this positive energy!\n\n"
                "Ways to maintain your positive state:\n"
                "🙏 **Gratitude Practice** – Note 3 good things from your day.\n"
                "🤝 **Share Positivity** – Your good mood can uplift those around you!\n"
                "💪 **Set New Goals** – Channel this energy towards your dreams.\n"
                "🌟 **Celebrate** – Take a moment to appreciate how far you've come!\n\n"
                "Keep going — you're doing absolutely great! 🚀")

    if any(w in msg for w in ['motivat', 'inspire', 'goal', 'dream', 'future', 'ambition', 'purpose']):
        return ("Here are some powerful insights to fuel your motivation:\n\n"
                "💡 *'The secret of getting ahead is getting started.'* — Mark Twain\n"
                "💡 *'You don't have to be great to start, but you have to start to be great.'*\n"
                "💡 *'Believe you can and you're halfway there.'* — Theodore Roosevelt\n\n"
                "🎯 **Tips to Stay Motivated:**\n"
                "1. Set clear short-term and long-term goals\n"
                "2. Visualize your success each morning\n"
                "3. Track your progress — even small steps count\n"
                "4. Find your deeper 'why' — your core purpose\n\n"
                "You have the potential to achieve incredible things! 🚀")

    if any(w in msg for w in ['meditat', 'mindful', 'calm', 'relax', 'peace', 'breathing exercise', 'breathe']):
        return ("Mindfulness and meditation are powerful tools for wellbeing! 🧘\n\n"
                "**Try this 5-Minute Meditation:**\n"
                "1. Sit comfortably, close your eyes\n"
                "2. Take 3 slow, deep breaths\n"
                "3. Focus on the sensation of breathing in and out\n"
                "4. When your mind wanders, gently return focus to your breath\n"
                "5. Continue for 5 minutes, then slowly open your eyes\n\n"
                "Even **5–10 minutes daily** can significantly reduce stress. "
                "Try apps like Headspace, Calm, or Insight Timer! 🌿")

    if any(w in msg for w in ['hello', 'hi', 'hey', 'good morning', 'good evening', 'good afternoon', 'hii', 'helo']):
        return ("Hello! 👋 Welcome to **MindEase** — your personal mental health support companion!\n\n"
                "I'm here to help you with:\n"
                "🧠 **Stress & Anxiety** – coping strategies\n"
                "📚 **Academic Pressure** – study tips and planning\n"
                "😴 **Sleep Issues** – better sleep habits\n"
                "💪 **Motivation** – staying inspired and goal-focused\n"
                "🧘 **Mindfulness** – relaxation and meditation techniques\n\n"
                "How are you feeling today? Feel free to share anything! 😊")

    if any(w in msg for w in ['help', 'support', 'advice', 'what can you do', 'how do you', 'guide']):
        return ("I'm **MindEase**, your AI mental health assistant! Here's what I can help with:\n\n"
                "💬 Try typing any of these:\n"
                "• *'I feel stressed'* – stress management techniques\n"
                "• *'I'm anxious'* – anxiety coping strategies\n"
                "• *'I'm feeling sad'* – emotional support\n"
                "• *'Study tips'* – academic performance advice\n"
                "• *'I can't sleep'* – sleep improvement guidance\n"
                "• *'Motivate me'* – inspirational words\n"
                "• *'Meditation'* – mindfulness exercises\n\n"
                "I'm always here for you — 24/7! 💙")

    # Fallback based on sentiment
    sentiment, score = analyze_sentiment(message)
    if sentiment in ['negative', 'highly_negative']:
        return ("I can sense that things might not be going well right now. That's okay — "
                "difficult days are a normal part of life. 💙\n\n"
                "Would you like to talk about:\n"
                "• **Stress or anxiety** you're experiencing?\n"
                "• **Academic challenges** you're facing?\n"
                "• **Relaxation techniques** to feel better?\n\n"
                "I'm here to listen and support you. You don't have to face this alone. 🌟")

    return ("Thank you for sharing with me! 😊 I'm here to support your mental well-being.\n\n"
            "You can ask me about:\n"
            "• Stress management and relaxation\n"
            "• Study tips and academic advice\n"
            "• Mindfulness and meditation\n"
            "• Sleep improvement strategies\n"
            "• Motivation and goal-setting\n\n"
            "What would you like to explore today? 🌟")


# ==============================================================================
# ROUTES
# ==============================================================================

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        age = request.form.get('age', type=int)
        course = request.form.get('course', '').strip()
        academic_year = request.form.get('academic_year', '').strip()
        institution = request.form.get('institution', '').strip()

        if not all([name, email, password]):
            flash('Please fill in all required fields.', 'danger')
            return render_template('auth/register.html')

        if User.query.filter_by(email=email).first():
            flash('Email already registered. Please log in.', 'danger')
            return render_template('auth/register.html')

        user = User(
            name=name, email=email, age=age, course=course,
            academic_year=academic_year, institution=institution
        )
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash(f'Welcome to MindEase, {name}! Your account has been created. 🎉', 'success')
        return redirect(url_for('dashboard'))
    return render_template('auth/register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        remember = bool(request.form.get('remember'))

        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user, remember=remember)
            next_page = request.args.get('next')
            flash(f'Welcome back, {user.name}! 👋', 'success')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('Invalid email or password. Please try again.', 'danger')
    return render_template('auth/login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out. Take care! 💙', 'info')
    return redirect(url_for('index'))


@app.route('/dashboard')
@login_required
def dashboard():
    recent_moods = MoodEntry.query.filter_by(user_id=current_user.id)\
                    .order_by(MoodEntry.timestamp.desc()).limit(7).all()
    recent_surveys = Survey.query.filter_by(user_id=current_user.id)\
                    .order_by(Survey.timestamp.desc()).limit(3).all()
    total_chats = ChatMessage.query.filter_by(user_id=current_user.id).count()

    avg_mood = 0
    if recent_moods:
        avg_mood = sum(m.mood_score for m in recent_moods) / len(recent_moods)

    if avg_mood >= 7:
        wellness_status, wellness_color, wellness_icon = 'Great', 'success', '😊'
    elif avg_mood >= 5:
        wellness_status, wellness_color, wellness_icon = 'Good', 'warning', '😐'
    elif avg_mood > 0:
        wellness_status, wellness_color, wellness_icon = 'Needs Attention', 'danger', '😟'
    else:
        wellness_status, wellness_color, wellness_icon = 'No Data Yet', 'secondary', '📊'

    mood_data = [{'score': m.mood_score, 'date': m.timestamp.strftime('%b %d'),
                  'notes': (m.notes or '')[:50]} for m in reversed(recent_moods)]

    return render_template('dashboard.html',
                           recent_moods=recent_moods,
                           recent_surveys=recent_surveys,
                           avg_mood=round(avg_mood, 1),
                           wellness_status=wellness_status,
                           wellness_color=wellness_color,
                           wellness_icon=wellness_icon,
                           total_chats=total_chats,
                           mood_data=json.dumps(mood_data))


@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        current_user.name = request.form.get('name', current_user.name).strip()
        current_user.age = request.form.get('age', type=int)
        current_user.course = request.form.get('course', '').strip()
        current_user.academic_year = request.form.get('academic_year', '').strip()
        current_user.institution = request.form.get('institution', '').strip()
        current_user.bio = request.form.get('bio', '').strip()
        db.session.commit()
        flash('Profile updated successfully! ✅', 'success')
    return render_template('profile.html')


@app.route('/mood', methods=['GET', 'POST'])
@login_required
def mood():
    if request.method == 'POST':
        mood_score = request.form.get('mood_score', type=int)
        notes = request.form.get('notes', '').strip()

        if not mood_score or not (1 <= mood_score <= 10):
            flash('Please provide a valid mood score (1–10).', 'danger')
            return redirect(url_for('mood'))

        sentiment, score = analyze_sentiment(notes) if notes else ('neutral', 0.0)
        entry = MoodEntry(
            user_id=current_user.id,
            mood_score=mood_score,
            notes=notes,
            sentiment=sentiment,
            sentiment_score=score
        )
        db.session.add(entry)
        db.session.commit()
        flash('Mood entry saved! Keep tracking your well-being. 😊', 'success')
        return redirect(url_for('dashboard'))
    return render_template('mood_tracker.html')


@app.route('/survey', methods=['GET', 'POST'])
@login_required
def survey():
    if request.method == 'POST':
        s = Survey(
            user_id=current_user.id,
            workload_level=request.form.get('workload_level', type=int),
            stress_level=request.form.get('stress_level', type=int),
            sleep_hours=request.form.get('sleep_hours', type=float),
            exercise=request.form.get('exercise') == 'yes',
            social_interaction=request.form.get('social_interaction', type=int),
            feedback=request.form.get('feedback', '').strip()
        )
        db.session.add(s)
        db.session.commit()
        flash('Weekly survey submitted! Thank you for sharing. 🙏', 'success')
        return redirect(url_for('analysis'))
    return render_template('survey.html')


@app.route('/analysis')
@login_required
def analysis():
    mood_entries = MoodEntry.query.filter_by(user_id=current_user.id)\
                    .order_by(MoodEntry.timestamp.desc()).limit(30).all()
    surveys = Survey.query.filter_by(user_id=current_user.id)\
                    .order_by(Survey.timestamp.desc()).limit(10).all()

    sentiment_counts = {'positive': 0, 'neutral': 0, 'negative': 0, 'highly_negative': 0}
    for entry in mood_entries:
        if entry.sentiment in sentiment_counts:
            sentiment_counts[entry.sentiment] += 1

    mood_trend = [{'date': e.timestamp.strftime('%b %d'), 'score': e.mood_score,
                   'sentiment': e.sentiment} for e in reversed(mood_entries)]

    overall_state = ('📊 No Data', 'neutral')
    if mood_entries:
        avg_score = sum(e.mood_score for e in mood_entries) / len(mood_entries)
        if avg_score >= 7:
            overall_state = ('😊 Positive', 'positive')
        elif avg_score >= 5:
            overall_state = ('😐 Neutral', 'neutral')
        elif avg_score >= 3:
            overall_state = ('😟 Stressed', 'negative')
        else:
            overall_state = ('😔 Needs Support', 'highly_negative')

    return render_template('analysis.html',
                           mood_entries=mood_entries,
                           surveys=surveys,
                           sentiment_counts=sentiment_counts,
                           mood_trend=json.dumps(mood_trend),
                           overall_state=overall_state)


@app.route('/chatbot')
@login_required
def chatbot():
    recent_messages = ChatMessage.query.filter_by(user_id=current_user.id)\
                        .order_by(ChatMessage.timestamp.asc()).limit(50).all()
    return render_template('chatbot.html', messages=recent_messages)


@app.route('/chatbot/respond', methods=['POST'])
@login_required
def chatbot_respond():
    data = request.get_json()
    if not data or not data.get('message'):
        return jsonify({'error': 'No message provided'}), 400

    message = data['message'].strip()
    if not message:
        return jsonify({'error': 'Empty message'}), 400

    response = generate_chatbot_response(message)
    sentiment, score = analyze_sentiment(message)

    chat_msg = ChatMessage(
        user_id=current_user.id,
        message=message,
        response=response,
        sentiment=sentiment
    )
    db.session.add(chat_msg)
    db.session.commit()

    return jsonify({'response': response, 'sentiment': sentiment})


@app.route('/awareness')
@login_required
def awareness():
    return render_template('awareness.html')


@app.route('/recommendations')
@login_required
def recommendations():
    recent_moods = MoodEntry.query.filter_by(user_id=current_user.id)\
                    .order_by(MoodEntry.timestamp.desc()).limit(7).all()
    recent_surveys = Survey.query.filter_by(user_id=current_user.id)\
                     .order_by(Survey.timestamp.desc()).limit(3).all()

    avg_mood = sum(m.mood_score for m in recent_moods) / len(recent_moods) if recent_moods else 5.0
    avg_stress = sum(s.stress_level for s in recent_surveys if s.stress_level) / len(recent_surveys) if recent_surveys else 3.0
    low_sleep = recent_surveys and any(s.sleep_hours and s.sleep_hours < 7 for s in recent_surveys)

    recs = []
    if avg_mood < 5 or avg_stress > 3:
        recs.append({'category': 'Stress Relief', 'icon': '🧘', 'priority': 'high',
                     'title': 'Mindfulness Meditation',
                     'desc': 'Start with 10 minutes of guided meditation daily. Use apps like Headspace or Calm for structured guidance.'})
        recs.append({'category': 'Physical Health', 'icon': '🚶', 'priority': 'high',
                     'title': 'Daily Physical Activity',
                     'desc': 'Even a 20-minute walk significantly reduces cortisol (stress hormone) levels and boosts mood.'})
    if low_sleep:
        recs.append({'category': 'Sleep', 'icon': '💤', 'priority': 'high',
                     'title': 'Improve Sleep Hygiene',
                     'desc': 'Stick to a consistent sleep schedule. Aim for 7–9 hours. Avoid screens 1 hour before bed.'})
    recs.append({'category': 'Study Skills', 'icon': '📚', 'priority': 'medium',
                 'title': 'Pomodoro Technique',
                 'desc': 'Study 25 min → 5 min break → Repeat 4 times → 20 min long break. Significantly boosts focus and retention.'})
    recs.append({'category': 'Social', 'icon': '🤝', 'priority': 'medium',
                 'title': 'Connect with Peers',
                 'desc': 'Joining study groups or social clubs reduces feelings of isolation and improves overall well-being.'})
    recs.append({'category': 'Nutrition', 'icon': '🥗', 'priority': 'low',
                 'title': 'Brain-Boosting Nutrition',
                 'desc': 'Include omega-3 rich foods (fish, nuts), berries, leafy greens, and dark chocolate for brain health.'})
    recs.append({'category': 'Motivation', 'icon': '⭐', 'priority': 'low',
                 'title': 'Daily Gratitude Journaling',
                 'desc': 'Write 3 things you\'re grateful for every day. This shifts your mindset towards positivity and builds resilience.'})
    recs.append({'category': 'Relaxation', 'icon': '🎵', 'priority': 'medium',
                 'title': 'Music & Creative Outlet',
                 'desc': 'Listening to calming music or engaging in creative activities lowers stress and promotes emotional well-being.'})
    recs.append({'category': 'Self-Care', 'icon': '🛀', 'priority': 'medium',
                 'title': 'Quality Me-Time',
                 'desc': 'Dedicate 30 minutes to something you love that isn\'t academic. Reading, a hobby, or a warm bath can reset your clock.'})
    recs.append({'category': 'Goal Setting', 'icon': '🎯', 'priority': 'low',
                 'title': 'Micro-Goal Planning',
                 'desc': 'Break your largest task into 3 tiny steps. Completing one small thing builds momentum and reduces procrastination.'})

    return render_template('recommendations.html', recommendations=recs, avg_mood=round(avg_mood, 1))


@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'danger')
        return redirect(url_for('dashboard'))

    all_users = User.query.filter_by(is_admin=False).all()
    total_users = len(all_users)
    total_moods = MoodEntry.query.count()
    total_chats = ChatMessage.query.count()
    total_surveys = Survey.query.count()

    at_risk_students = []
    for user in all_users:
        moods = MoodEntry.query.filter_by(user_id=user.id)\
                .order_by(MoodEntry.timestamp.desc()).limit(5).all()
        if moods:
            avg = sum(m.mood_score for m in moods) / len(moods)
            if avg < 5:
                at_risk_students.append({
                    'user': user,
                    'avg_mood': round(avg, 1),
                    'last_entry': moods[0].timestamp.strftime('%Y-%m-%d'),
                    'sentiment': moods[0].sentiment
                })

    all_moods = MoodEntry.query.all()
    mood_dist = {'Low (1-3)': 0, 'Medium (4-6)': 0, 'High (7-10)': 0}
    for m in all_moods:
        if m.mood_score <= 3:
            mood_dist['Low (1-3)'] += 1
        elif m.mood_score <= 6:
            mood_dist['Medium (4-6)'] += 1
        else:
            mood_dist['High (7-10)'] += 1

    sentiment_dist = {'positive': 0, 'neutral': 0, 'negative': 0, 'highly_negative': 0}
    for m in all_moods:
        if m.sentiment in sentiment_dist:
            sentiment_dist[m.sentiment] += 1

    return render_template('admin/dashboard.html',
                           all_users=all_users,
                           total_users=total_users,
                           total_moods=total_moods,
                           total_chats=total_chats,
                           total_surveys=total_surveys,
                           at_risk_students=at_risk_students,
                           mood_dist=json.dumps(mood_dist),
                           sentiment_dist=json.dumps(sentiment_dist))


# ==============================================================================
# APP STARTUP
# ==============================================================================

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        admin = User.query.filter_by(email='admin@mindease.com').first()
        if not admin:
            admin = User(
                name='Admin',
                email='admin@mindease.com',
                is_admin=True,
                course='Administration',
                institution='MindEase Platform'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print("✅ Admin created: admin@mindease.com / admin123")
    print("🚀 MindEase Mental Health Platform running at http://127.0.0.1:5000")
    app.run(debug=True, port=5000)
