// MindEase Chatbot JS

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatInput');
  const messages = document.getElementById('chatMessages');
  const sendBtn = document.getElementById('sendBtn');

  if (!form) return;

  // Auto-scroll to bottom
  scrollToBottom();

  // Submit on Enter (Shift+Enter for newline)
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  // Auto-resize textarea
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 120) + 'px';
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    sendMessage();
  });

  function sendMessage() {
    const msg = input.value.trim();
    if (!msg) return;

    appendMessage('user', msg);
    input.value = '';
    input.style.height = 'auto';
    setBtnLoading(true);

    const typingEl = appendTyping();

    fetch('/chatbot/respond', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      body: JSON.stringify({ message: msg })
    })
    .then(r => r.json())
    .then(data => {
      typingEl.remove();
      setBtnLoading(false);
      if (data.response) {
        appendMessage('bot', data.response, data.sentiment);
      } else {
        appendMessage('bot', 'I\'m sorry, something went wrong. Please try again.');
      }
    })
    .catch(() => {
      typingEl.remove();
      setBtnLoading(false);
      appendMessage('bot', 'Connection error. Please check your connection and try again. 🔄');
    });
  }

  function appendMessage(type, text, sentiment) {
    const now = new Date();
    const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const wrapper = document.createElement('div');
    wrapper.style.display = 'flex';
    wrapper.style.flexDirection = 'column';
    wrapper.style.alignItems = type === 'user' ? 'flex-end' : 'flex-start';

    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${type}`;
    bubble.innerHTML = formatMessage(text) + `<div class="chat-meta">${time}${type === 'bot' && sentiment ? ' · ' + sentimentEmoji(sentiment) : ''}</div>`;

    wrapper.appendChild(bubble);
    messages.appendChild(wrapper);
    scrollToBottom();
  }

  function appendTyping() {
    const wrapper = document.createElement('div');
    wrapper.style.display = 'flex';
    wrapper.style.alignItems = 'flex-start';

    const bubble = document.createElement('div');
    bubble.className = 'chat-bubble bot';
    bubble.innerHTML = '<div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div>';

    wrapper.appendChild(bubble);
    messages.appendChild(wrapper);
    scrollToBottom();
    return wrapper;
  }

  function formatMessage(text) {
    // Bold **text**
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Italic *text*
    text = text.replace(/\*(.*?)\*/g, '<em>$1</em>');
    // Newlines
    text = text.replace(/\n/g, '<br>');
    return text;
  }

  function sentimentEmoji(sentiment) {
    const map = { positive: '😊', neutral: '😐', negative: '😟', highly_negative: '💙' };
    return map[sentiment] || '';
  }

  function setBtnLoading(loading) {
    if (loading) {
      sendBtn.innerHTML = '<div class="spinner"></div>';
      sendBtn.disabled = true;
    } else {
      sendBtn.innerHTML = '➤';
      sendBtn.disabled = false;
    }
  }

  function scrollToBottom() {
    setTimeout(() => {
      messages.scrollTop = messages.scrollHeight;
    }, 50);
  }
});
