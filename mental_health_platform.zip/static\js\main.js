// MindEase Main JS

document.addEventListener('DOMContentLoaded', () => {
  initFlashMessages();
  initRangeSliders();
  initMoodEmoji();
  initSidebarActive();
});

// ─── Flash Messages ────────────────────────────────────────────────────────
function initFlashMessages() {
  document.querySelectorAll('.alert-close').forEach(btn => {
    btn.addEventListener('click', () => {
      const alert = btn.closest('.alert');
      alert.style.animation = 'slideOutRight 0.3s ease forwards';
      setTimeout(() => alert.remove(), 300);
    });
  });
  // Auto-dismiss after 5 seconds
  setTimeout(() => {
    document.querySelectorAll('.alert').forEach(alert => {
      if (alert) {
        alert.style.animation = 'slideOutRight 0.4s ease forwards';
        setTimeout(() => alert.remove(), 400);
      }
    });
  }, 5000);
}

// ─── Range Sliders ─────────────────────────────────────────────────────────
function initRangeSliders() {
  document.querySelectorAll('.form-range').forEach(range => {
    const display = document.getElementById(range.id + '_display');
    const update = () => {
      if (display) {
        display.textContent = range.value;
        // Update gradient fill
        const pct = ((range.value - range.min) / (range.max - range.min)) * 100;
        range.style.background = `linear-gradient(to right, var(--primary) ${pct}%, var(--bg-glass-strong) ${pct}%)`;
      }
    };
    range.addEventListener('input', update);
    update();
  });
}

// ─── Mood Emoji ────────────────────────────────────────────────────────────
function initMoodEmoji() {
  const moodRange = document.getElementById('mood_score');
  const emojiDisplay = document.getElementById('mood_emoji');
  if (!moodRange || !emojiDisplay) return;

  const emojis = {
    1: '😭', 2: '😢', 3: '😟', 4: '😕', 5: '😐',
    6: '🙂', 7: '😊', 8: '😄', 9: '😁', 10: '🤩'
  };
  const moodLabels = {
    1: 'Terrible', 2: 'Very Bad', 3: 'Bad', 4: 'Not Great', 5: 'Okay',
    6: 'Pretty Good', 7: 'Good', 8: 'Great', 9: 'Very Good', 10: 'Amazing!'
  };

  const moodLabel = document.getElementById('mood_label');
  const update = () => {
    const val = parseInt(moodRange.value);
    emojiDisplay.textContent = emojis[val] || '😐';
    emojiDisplay.style.transform = 'scale(1.2)';
    if (moodLabel) moodLabel.textContent = moodLabels[val] || '';
    setTimeout(() => { emojiDisplay.style.transform = 'scale(1)'; }, 200);
  };
  moodRange.addEventListener('input', update);
  update();
}

// ─── Sidebar Active Link ───────────────────────────────────────────────────
function initSidebarActive() {
  const path = window.location.pathname;
  document.querySelectorAll('.sidebar-link').forEach(link => {
    if (link.getAttribute('href') === path) {
      link.classList.add('active');
    }
  });
}

// ─── Dashboard Charts ──────────────────────────────────────────────────────
function initMoodChart(moodData) {
  const ctx = document.getElementById('moodChart');
  if (!ctx || !moodData || !moodData.length) return;

  new Chart(ctx, {
    type: 'line',
    data: {
      labels: moodData.map(d => d.date),
      datasets: [{
        label: 'Mood Score',
        data: moodData.map(d => d.score),
        borderColor: '#8b5cf6',
        backgroundColor: 'rgba(139,92,246,0.1)',
        borderWidth: 2.5,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: '#8b5cf6',
        pointBorderColor: '#0a0a1a',
        pointBorderWidth: 2,
        pointRadius: 5,
        pointHoverRadius: 7,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(15,15,35,0.9)',
          borderColor: 'rgba(139,92,246,0.4)',
          borderWidth: 1,
          titleColor: '#f1f5f9',
          bodyColor: '#94a3b8',
          padding: 12,
          callbacks: {
            label: ctx => `Mood: ${ctx.parsed.y}/10`
          }
        }
      },
      scales: {
        y: { min: 0, max: 10, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#64748b', stepSize: 2 }, border: { display: false } },
        x: { grid: { display: false }, ticks: { color: '#64748b' }, border: { display: false } }
      }
    }
  });
}

function initSentimentChart(sentimentCounts) {
  const ctx = document.getElementById('sentimentChart');
  if (!ctx) return;
  const labels = ['Positive', 'Neutral', 'Negative', 'Highly Negative'];
  const data = [
    sentimentCounts.positive || 0,
    sentimentCounts.neutral || 0,
    sentimentCounts.negative || 0,
    sentimentCounts.highly_negative || 0
  ];
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: ['rgba(16,185,129,0.8)', 'rgba(59,130,246,0.8)', 'rgba(245,158,11,0.8)', 'rgba(239,68,68,0.8)'],
        borderColor: '#0a0a1a',
        borderWidth: 2,
        hoverOffset: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '70%',
      plugins: {
        legend: { position: 'bottom', labels: { color: '#94a3b8', padding: 16, font: { size: 12 } } },
        tooltip: {
          backgroundColor: 'rgba(15,15,35,0.9)',
          borderColor: 'rgba(139,92,246,0.4)',
          borderWidth: 1,
          titleColor: '#f1f5f9',
          bodyColor: '#94a3b8',
          padding: 12
        }
      }
    }
  });
}

function initAdminMoodDist(moodDist) {
  const ctx = document.getElementById('moodDistChart');
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: Object.keys(moodDist),
      datasets: [{
        label: 'Students',
        data: Object.values(moodDist),
        backgroundColor: ['rgba(239,68,68,0.7)', 'rgba(245,158,11,0.7)', 'rgba(16,185,129,0.7)'],
        borderRadius: 8,
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { backgroundColor: 'rgba(15,15,35,0.9)', borderColor: 'rgba(139,92,246,0.4)', borderWidth: 1, titleColor: '#f1f5f9', bodyColor: '#94a3b8', padding: 12 }
      },
      scales: {
        y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#64748b' }, border: { display: false } },
        x: { grid: { display: false }, ticks: { color: '#64748b' }, border: { display: false } }
      }
    }
  });
}

// Add slide out animation
const style = document.createElement('style');
style.textContent = '@keyframes slideOutRight { to { opacity: 0; transform: translateX(30px); } }';
document.head.appendChild(style);
